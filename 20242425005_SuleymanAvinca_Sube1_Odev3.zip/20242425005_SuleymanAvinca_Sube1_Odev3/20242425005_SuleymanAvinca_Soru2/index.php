<!DOCTYPE html>
<html>
<head>
    <title>Sepet</title>
</head>
<body>

<h2>Sepet Hesaplama</h2>

<form action="hesapla.php" method="POST">

Ürün Adı:<br>
<input type="text" name="urun"><br><br>

Fiyat:<br>
<input type="number" name="fiyat"><br><br>

Adet:<br>
<input type="number" name="adet"><br><br>

KDV (%):<br>
<input type="number" name="kdv"><br><br>

İndirim Kodu:<br>
<input type="text" name="indirim"><br><br>

<button type="submit">Hesapla</button>

</form>

</body>
</html>