<?php

$urun = $_POST["urun"] ?? "";
$fiyat = (float)($_POST["fiyat"] ?? 0);
$adet = (int)($_POST["adet"] ?? 0);
$kdv = (float)($_POST["kdv"] ?? 0);
$indirim = strtoupper($_POST["indirim"] ?? "");

if($urun == "" || $fiyat <= 0 || $adet <= 0 || $kdv < 20){
    echo "Hatalı giriş yaptınız";
    exit;
}

$ara = $fiyat * $adet;
$kdv_tutar = $ara * ($kdv / 100);

$indirim_oran = 0;

if($indirim == "IND20"){
    $indirim_oran = 20;
}
else if($indirim == "IND50"){
    $indirim_oran = 50;
}

$indirim_tutar = $ara * ($indirim_oran / 100);

$genel = $ara + $kdv_tutar - $indirim_tutar;

?>

<!DOCTYPE html>
<html>
<head>
    <title>Sonuç</title>
</head>
<body>

<h2>Sonuç</h2>

Ürün: <?php echo $urun; ?><br>
Ara Toplam: <?php echo $ara; ?> TL<br>
KDV: <?php echo $kdv_tutar; ?> TL<br>
İndirim: <?php echo $indirim_tutar; ?> TL<br>
<h3>Genel Toplam: <?php echo $genel; ?> TL</h3>

<br>
<a href="index.html">Geri Dön</a>

</body>
</html>