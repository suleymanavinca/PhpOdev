<?php
session_start();

$dogru_kullanici = "admin";
$dogru_sifre = "1234";

$k = $_POST["kullanici"] ?? "";
$s = $_POST["sifre"] ?? "";

if($k == "" || $s == ""){
    $_SESSION["mesaj"] = "Lütfen tüm alanları doldurun";
    $_SESSION["renk"] = "red";
    header("Location: index.php");
    exit;
}

if($k == $dogru_kullanici && $s == $dogru_sifre){
    $_SESSION["giris"] = true;
    header("Location: panel.php");
    exit;
} else {
    $_SESSION["mesaj"] = "Kullanıcı adı veya şifre hatalı";
    $_SESSION["renk"] = "red";
    header("Location: index.php");
    exit;
}