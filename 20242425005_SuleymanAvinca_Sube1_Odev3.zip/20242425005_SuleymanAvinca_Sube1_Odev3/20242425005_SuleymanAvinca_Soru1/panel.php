<?php
session_start();

if(!isset($_SESSION["giris"])){
    header("Location: index.php");
    exit;
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Panel</title>
</head>
<body>

<h2>Giriş başarılı, hoş geldiniz admin</h2>

<a href="cikis.php">Çıkış Yap</a>

</body>
</html>