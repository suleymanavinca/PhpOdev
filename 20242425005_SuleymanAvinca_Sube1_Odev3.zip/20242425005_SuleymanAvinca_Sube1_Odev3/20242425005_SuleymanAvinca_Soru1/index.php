<?php
session_start();

$mesaj = $_SESSION["mesaj"] ?? "";
$renk = $_SESSION["renk"] ?? ""; 
unset($_SESSION["mesaj"], $_SESSION["renk"]);
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <title>Login</title>
</head>
<body>

<h2>Kullanıcı Girişi</h2>

<?php if($mesaj): ?>
    <p style="color: <?php echo htmlspecialchars($renk); ?>;">
        <?php echo htmlspecialchars($mesaj); ?>
    </p>
<?php endif; ?>

<form method="POST" action="kontrol.php">
    Kullanıcı Adı: <br>
    <input type="text" name="kullanici" required><br><br>

    Şifre: <br>
    <input type="password" name="sifre" required><br><br>

    <button type="submit">Giriş Yap</button>
</form>

</body>
</html>