<?php
$ad = "Suleyman Avinca";
$no = "20242425005";

$site = "Kariyer Fuarı Başvuru ve Görüşme Sistemi";

$heroBaslik = "Öğrenci ve firmaları aynı sistemde buluşturan basit uygulama";
$heroYazi = "Firmaları görüntüleme, başvuru oluşturma ve görüşme bilgilerini tek sayfada takip etme yapısı sunar.";

$amacBaslik = "Bu uygulama amacı nedir, hangi sorunu çözüyor?";
$amacYazi = "Bu uygulamanın amacı, kariyer günlerinde öğrenciler ile firmaları aynı sistem içinde buluşturmaktır. Öğrenciler firmaları, açık pozisyonları ve başvuru süreçlerini tek bir yerden görebilir. Firmalar da başvuruları daha düzenli şekilde inceleyebilir. Böylece karışıklık, zaman kaybı ve iletişim eksikliği azalır.";

$kulBaslik = "Bu uygulama hangi kullanıcıları etkiliyor ve hangileri için çözüm olacak?";
$kulYazi = "Bu uygulama üç farklı kullanıcı için çözüm sunar. Birinci kullanıcı öğrencidir. Öğrenci firmaları görüntüler, başvuru yapar ve görüşme durumunu takip eder. İkinci kullanıcı firma yetkilisidir. Firma yetkilisi ilan ekler, başvuruları inceler ve görüşme planı oluşturur. Üçüncü kullanıcı yöneticidir. Yönetici sistemin genel kontrolünü sağlar, firma ve kullanıcı yönetimini yapar.";

$tekBaslik = "Bu uygulama geliştirmek için hangi bileşenlere ve ön yüz/arka yüzde nasıl bir tasarımı ve teknolojileri olacak?";
$tekYazi = "Uygulamanın ön yüzünde ana sayfa, firma listesi, başvuru ekranı ve iletişim bölümü olacaktır. Tasarım sade, anlaşılır ve mobil uyumlu olacaktır. Arka yüzde kullanıcı bilgileri, firma kayıtları, başvurular ve görüşme verileri tutulacaktır. Geliştirme için HTML, CSS, PHP kullanılacaktır. Ön yüz kullanıcıya kolay kullanım sağlayacak, arka yüz ise verilerin düzenli yönetilmesini sağlayacaktır.";

$roller = [
    "Öğrenci",
    "Firma Yetkilisi",
    "Yönetici"
];

$firmalar = [
    ["firma" => "Nova Yazılım", "pozisyon" => "Stajyer", "yer" => "İstanbul"],
    ["firma" => "TeknoLab", "pozisyon" => "Frontend Geliştirici", "yer" => "Ankara"],
    ["firma" => "CodeBase", "pozisyon" => "Backend Stajyeri", "yer" => "İzmir"]
];

$basvuru = [
    "ad" => "Suleyman Avinca",
    "pozisyon" => "Stajyer",
    "durum" => "Başvuru Alındı"
];

$gorusme = [
    "firma" => "Nova Yazılım",
    "tarih" => "26.03.2026",
    "saat" => "14:30",
    "yer" => "Kariyer Merkezi - Salon 2"
];

$iletisimMail = "kariyer@example.com";
$iletisimTel = "+90 555 555 55 55";
?>
<!doctype html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $site; ?></title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<header class="ust">
    <div class="kutu ustSatir">
        <div class="logo"><?php echo $site; ?></div>
        <nav class="menu">
            <a href="#anasayfa">Ana Sayfa</a>
            <a href="#amac">Amaç</a>
            <a href="#kullanicilar">Kullanıcılar</a>
            <a href="#firmalar">Firmalar</a>
            <a href="#basvuru">Başvuru</a>
            <a href="#gorusme">Görüşme</a>
            <a href="#iletisim">İletişim</a>
        </nav>
    </div>
</header>

<section class="hero" id="anasayfa">
    <div class="kutu">
        <p class="kimlik"><?php echo $ad; ?> | <?php echo $no; ?></p>
        <h1><?php echo $heroBaslik; ?></h1>
        <p class="altYazi"><?php echo $heroYazi; ?></p>
        <div class="butonlar">
            <a href="#firmalar" class="btn">Firmaları Gör</a>
            <a href="#basvuru" class="btn2">Başvuru Alanı</a>
        </div>
    </div>
</section>

<main class="kutu ana">

    <section id="amac" class="kart buyuk">
        <span class="etiket">a</span>
        <h2><?php echo $amacBaslik; ?></h2>
        <p><?php echo $amacYazi; ?></p>
    </section>

    <section id="kullanicilar" class="ikiKolon">
        <div class="kart">
            <span class="etiket">b</span>
            <h2><?php echo $kulBaslik; ?></h2>
            <p><?php echo $kulYazi; ?></p>
        </div>

        <div class="kart">
            <h3>Kullanıcı Rolleri</h3>
            <ul>
                <?php foreach ($roller as $rol) { ?>
                    <li><?php echo $rol; ?></li>
                <?php } ?>
            </ul>
        </div>
    </section>

    <section class="ikiKolon">
        <div class="kart">
            <span class="etiket">c</span>
            <h2><?php echo $tekBaslik; ?></h2>
            <p><?php echo $tekYazi; ?></p>
        </div>

        <div class="kart">
            <h3>Ön Yüz Yapısı</h3>
            <ul>
                <li>Ana Sayfa</li>
                <li>Firma Listesi</li>
                <li>Başvuru Ekranı</li>
                <li>İletişim Bölümü</li>
            </ul>
        </div>
    </section>

    <section id="firmalar" class="bolum">
        <div class="baslikAlan">
            <h2>Firma Listesi</h2>
            <p>Öğrencilerin başvuru yapabileceği örnek firmalar</p>
        </div>

        <div class="kartlar">
            <?php foreach ($firmalar as $firma) { ?>
                <div class="kart firmaKart">
                    <h3><?php echo $firma["firma"]; ?></h3>
                    <p><strong>Pozisyon:</strong> <?php echo $firma["pozisyon"]; ?></p>
                    <p><strong>Konum:</strong> <?php echo $firma["yer"]; ?></p>
                    <a href="#basvuru" class="kucukBtn">Başvur</a>
                </div>
            <?php } ?>
        </div>
    </section>

    <section id="basvuru" class="ikiKolon">
        <div class="kart">
            <h2>Başvuru Ekranı</h2>
            <form class="formAlan" id="basvuruForm">
                <label>Ad Soyad</label>
                <input type="text" id="adInput" value="<?php echo $basvuru["ad"]; ?>">

                <label>Pozisyon</label>
                <input type="text" id="pozisyonInput" value="<?php echo $basvuru["pozisyon"]; ?>">

                <label>Durum</label>
                <input type="text" id="durumInput" value="<?php echo $basvuru["durum"]; ?>" readonly>

                <button type="submit">Başvuru Oluştur</button>

                <div id="mesajKutusu" class="mesaj"></div>
            </form>
        </div>

        <div class="kart">
            <h3>Başvuru Bilgisi</h3>
            <p>Bu alan veritabanı olmadan örnek olarak hazırlanmıştır.</p>
            <div class="bilgiKutusu">
                <p><strong>Öğrenci:</strong> <span id="gosterAd"><?php echo $basvuru["ad"]; ?></span></p>
                <p><strong>Pozisyon:</strong> <span id="gosterPozisyon"><?php echo $basvuru["pozisyon"]; ?></span></p>
                <p><strong>Durum:</strong> <span id="gosterDurum"><?php echo $basvuru["durum"]; ?></span></p>
            </div>
        </div>
    </section>

    <section id="gorusme" class="ikiKolon">
        <div class="kart">
            <h2>Görüşme Bilgileri</h2>
            <p>Başvurudan sonra öğrencinin görüntüleyebileceği örnek görüşme ekranı</p>
            <div class="bilgiKutusu">
                <p><strong>Firma:</strong> <?php echo $gorusme["firma"]; ?></p>
                <p><strong>Tarih:</strong> <?php echo $gorusme["tarih"]; ?></p>
                <p><strong>Saat:</strong> <?php echo $gorusme["saat"]; ?></p>
                <p><strong>Yer:</strong> <?php echo $gorusme["yer"]; ?></p>
            </div>
        </div>

        <div class="kart">
            <h3>Sistem Özeti</h3>
            <ul>
                <li>Firma görüntüleme</li>
                <li>Başvuru oluşturma</li>
                <li>Durum takip etme</li>
                <li>Görüşme planı görme</li>
            </ul>
        </div>
    </section>

    <section id="iletisim" class="ikiKolon">
        <div class="kart">
            <h2>İletişim</h2>
            <p>Öğrenci ve firma yetkilileri iletişim bilgilerine bu bölümden ulaşabilir.</p>
            <div class="bilgiKutusu">
                <p><strong>E-posta:</strong> <?php echo $iletisimMail; ?></p>
                <p><strong>Telefon:</strong> <?php echo $iletisimTel; ?></p>
            </div>
        </div>

        <div class="kart">
            <h3>Hızlı Erişim</h3>
            <a href="#anasayfa" class="kucukBtn">Ana Sayfaya Dön</a>
        </div>
    </section>

</main>

<footer class="alt">
    <div class="kutu">
        <p><?php echo $site; ?></p>
        <p><?php echo $ad; ?> - <?php echo $no; ?></p>
    </div>
</footer>

<script>
document.addEventListener("DOMContentLoaded", function () {
    var form = document.getElementById("basvuruForm");

    form.addEventListener("submit", function(e) {
        e.preventDefault();

        var ad = document.getElementById("adInput").value;
        var pozisyon = document.getElementById("pozisyonInput").value;

        document.getElementById("gosterAd").textContent = ad;
        document.getElementById("gosterPozisyon").textContent = pozisyon;
        document.getElementById("gosterDurum").textContent = "Başvuru Gönderildi";
        document.getElementById("durumInput").value = "Başvuru Gönderildi";

        var mesaj = document.getElementById("mesajKutusu");
        mesaj.textContent = "Başvurunuz başarıyla gönderildi.";
        mesaj.style.display = "block";
    });
});
</script>

</body>
</html>